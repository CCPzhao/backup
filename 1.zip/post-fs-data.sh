MODDIR=${0%/*}
#启用
touch /data/adb/modules/riru_momohider/config/denylist
touch /data/adb/modules/riru_momohider/config/initrc
touch /data/adb/modules/riru_momohider/config/app_zygote_magic
touch /data/adb/modules/riru_momohider/config/isolated
touch /data/adb/modules/riru_momohider/config/qidm
touch /data/adb/modules/riru_momohider/config/sdi
touch /data/adb/modules/riru_momohider/config/setns
#删废

rm -rf /data/system/xedge
#删自
rm -rf /data/adb/modules/Hide_exceptions/post-fs-data.sh

