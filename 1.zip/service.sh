MODDIR=${0%/*}
echo 1 >/data/local/tmp/fake
chmod 755 /data/local/tmp/fake
mount --bind /data/local/tmp/fake /sys/fs/selinux/enforce
while [ -z "$boot" ]; do
	sleep 10
	boot=$(getprop ro.boot.bootreason)
done
#↑开关↓解锁
ac=null
until [ $ac = "false" ];do
    #rosan检测
	ac=$(/system/bin/app_process -Djava.class.path=$MODDIR/compilations.dex /system/bin com.rosan.shell.ActiviteJava)
	sleep 5
done
Print_Time=$( "+%m.%d.%R")
mv /sdcard/TWRP /sdcard/TWRP$Print_Time
rm -rf /system/addon.d
settings delete global hidden_api_policy
settings delete global hidden_api_policy_p_apps
settings delete global hidden_api_policy_pre_p_apps
settings delete global hidden_api_blacklist_exemptions
resetprop --delete dalvik.vm.dex2oat-flags