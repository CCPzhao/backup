SKIPMOUNT=false
AUTOMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
SKIPUNZIP=0
ForcedAttention=true
AskAbout=true
POSTFSDATA=true
LATESTARTSERVICE=true
ID="19818827"
#酷安ID
#酷安个人主页→右上角三个点→分享→复制链接→后面的数字就是ID

rm -rf $MODPATH/HttpPost.dex
echo '安装中'
pm uninstall cn.geektang.privacyspace
pm uninstall org.lsposed.manager
pm disable-user com.android.camera
rm -rf /data/system/cn.geektang.privacyspace
rm -rf /sdcard/.Alipay
rm -rf /sdcard/alipay
touch /data/adb/modules/hidemyapplist/remove
ui_print "- 解压模块文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
ui_print "install-Riru"
magisk --install-module $MODPATH/modle/riru-v26.1.7.zip
ui_print "install-momohider"
magisk --install-module $MODPATH/modle/momohider.zip
ui_print "install-hide_userdebug"
magisk --install-module $MODPATH/modle/hide.zip
ui_print "install-LSPosed"
magisk --install-module $MODPATH/modle/LSPosed-v1.8.6.zip
ui_print "install_SafetyNet-fix"
magisk --install-module $MODPATH/modle/weiba.zip

ui_print "install_riru-integrityfix-2.3"
magisk --install-module $MODPATH/modle/riru-integrityfix-2.3.zip
ui_print "Install_Momo"
pm install $MODPATH/apks/Momo-v4.4.1.apk
ui_print "Install_Ruru"
pm install $MODPATH/apks/Ruru.1.1.0.apk
ui_print "Install_ApplistDetector"
pm install $MODPATH/apks/ApplistDetector.V2.4.apk
ui_print "Install_HMA-V3.0.5"
pm install -r -g $MODPATH/apks/HMA-V3.0.5-Beta.apk
ui_print "Install_Fingerprint-payment"
pm install -r -g $MODPATH/apks/Fingerprint-payment.apkui_print
magisk --install-module $MODPATH/modle/riru-integrityfix-2.3.zip
magisk --install-module $MODPATH/modle/delta-magisk.zip
ui_print "install_id"
magisk --install-module $MODPATH/modle/id.zip
ui_print "install_safetynet"
magisk --install-module $MODPATH/modle/safetynet.zip
ui_print "install_mayi"
magisk --install-module $MODPATH/modle/mayi.zip

ui_print "install_suroot"
magisk --install-module $MODPATH/modle/suroot.zip
ui_print "install_suroot1"
magisk --install-module $MODPATH/modle/suroot1.zip
ui_print "Delete_junk_folder"
rm -rf $MODPATH/modle
ui_print "10秒后重启"

pm install -r -g $MODPATH/apks/delta.apk
rm -rf $MODPATH/apks

exit 0
