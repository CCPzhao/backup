// 全局变量
let foundNotes = new Set(); // 用于去重
let currentTabId = null;
let matchedAccount = null;
let isFirstMatch = true;

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
  // 绑定事件监听器
  bindEventListeners();
  
  // 初始化数据
  initializeData();
  
  // 监听来自content.js的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'FOUND_ELEMENTS') {
      handleFoundElements(message.elements);
      sendResponse({ success: true });
    }
    return true;
  });
});

// 初始化数据
async function initializeData() {
  try {
    // 获取当前标签页信息
    const tab = await getCurrentTab();
    currentTabId = tab.id;
    
    // 从存储中读取数据
    await loadDataFromStorage();
  } catch (error) {
    console.error('初始化数据失败:', error);
  }
}



// 绑定事件监听器
function bindEventListeners() {
  // 匹配账号按钮
  const matchBtn = document.getElementById('match-btn');
  matchBtn.addEventListener('click', matchAccount);
  
  // 停止查找按钮
  const stopBtn = document.getElementById('stop-btn');
  stopBtn.addEventListener('click', stopFindElements);
  
  // 提交按钮
  const submitBtn = document.getElementById('submit-btn');
  submitBtn.addEventListener('click', submitNotes);
}

// 匹配账号功能
async function matchAccount() {
  const noticeDiv = document.getElementById('match-notice');
  const resultDiv = document.getElementById('match-result');
  
  // 第一次点击匹配时，不显示提示
  // 再次点击时，显示"需要重新获取，请刷新该页面"提示，不再执行其他逻辑
  if (!isFirstMatch) {
    noticeDiv.textContent = '需要重新获取，请刷新该页面';
    noticeDiv.className = 'match-notice show';
    return; // 直接返回，不执行后续逻辑
  }
  
  resultDiv.textContent = '正在匹配...';
  resultDiv.className = 'match-result';
  
  try {
    // 获取当前标签页信息
    const tab = await getCurrentTab();
    currentTabId = tab.id;
    const url = tab.url;
    
    // 检测URL是否符合要求
    let platform = '';
    let accountIdFromUrl = '';
    
    if (url.includes('douyin.com/user/')) {
      platform = 'dy';
      // 正则提取抖音URL中的accountId
      const dyMatch = url.match(/douyin\.com\/user\/([^?]+)/);
      if (dyMatch && dyMatch[1]) {
        accountIdFromUrl = dyMatch[1];
      } else {
        throw new Error('无法从抖音URL中提取accountId');
      }
    } else if (url.includes('xiaohongshu.com/user/profile/')) {
      platform = 'xhs';
      // 正则提取小红书URL中的accountId
      const xhsMatch = url.match(/xiaohongshu\.com\/user\/profile\/([^?]+)/);
      if (xhsMatch && xhsMatch[1]) {
        accountIdFromUrl = xhsMatch[1];
      } else {
        throw new Error('无法从小红书URL中提取accountId');
      }
    } else {
      throw new Error('当前页面不是抖音或小红书的用户页面');
    }
    
    // 请求后端接口获取账号列表
    const accounts = await fetchAccounts();
    
    // 匹配账号
    matchedAccount = accounts.find(acc => 
      acc.platform === platform && acc.accountId === accountIdFromUrl
    );
    
    if (matchedAccount) {
      // 只显示当前数据，简化提示
      resultDiv.textContent = `平台: ${platform === 'dy' ? '抖音' : '小红书'} 用户ID: ${matchedAccount.userId}\n账号ID: ${matchedAccount.accountId}`;
      resultDiv.className = 'match-result success';
      
      console.log('匹配成功的账号:', matchedAccount);
      
      // 保存匹配结果到存储
      saveDataToStorage();
      
      // 发送消息给content.js，开始查找页面元素
      chrome.tabs.sendMessage(tab.id, { type: 'START_FIND_ELEMENTS' }, (response) => {
        if (response && response.success) {
          console.log('开始查找页面元素');
        } else {
          console.error('发送查找元素消息失败:', response.error);
        }
      });
      
      // 第一次匹配成功后，设置为非首次匹配
      isFirstMatch = false;
    } else {
      resultDiv.textContent = '未找到匹配的账号';
      resultDiv.className = 'match-result error';
    }
    
  } catch (error) {
    resultDiv.textContent = `错误: ${error.message}`;
    resultDiv.className = 'match-result error';
    console.error('匹配账号失败:', error);
  }
}

// 停止查找元素
function stopFindElements() {
  if (currentTabId) {
    chrome.tabs.sendMessage(currentTabId, { type: 'STOP_FIND_ELEMENTS' }, (response) => {
      if (response && response.success) {
        console.log('停止查找页面元素');
        // 在提示词标签中更改成"已停止查找笔记"的提示
        const noticeDiv = document.getElementById('match-notice');
        noticeDiv.textContent = '已停止查找笔记';
        noticeDiv.className = 'match-notice show';
      } else {
        console.error('发送停止查找消息失败:', response.error);
      }
    });
  }
}

// 处理找到的元素
function handleFoundElements(elements) {
  if (!elements || elements.length === 0) {
    return;
  }
  
  let hasNewElements = false;
  
  elements.forEach(element => {
    // 生成唯一键，用于去重
    const uniqueKey = `${element.href}_${element.content}`;
    if (!foundNotes.has(uniqueKey)) {
      foundNotes.add(uniqueKey);
      addNoteToUI(element);
      hasNewElements = true;
    }
  });
  
  // 更新笔记总数
  updateNotesCount();
  
  // 如果有新元素，保存到存储
  if (hasNewElements) {
    saveDataToStorage();
  }
}

// 添加笔记到UI
function addNoteToUI(element) {
  const notesList = document.getElementById('notes-list');
  
  // 移除空状态提示
  const emptyNotes = notesList.querySelector('.empty-notes');
  if (emptyNotes) {
    emptyNotes.remove();
  }
  
  // 获取当前笔记数量（用于序列号）
  const currentCount = foundNotes.size;
  
  // 创建笔记项
  const noteItem = document.createElement('div');
  noteItem.className = 'note-item';
  
  // 创建标题行容器，确保序列号和标题在同一行
  const titleRow = document.createElement('div');
  titleRow.className = 'note-title-row';
  
  // 创建序列号，格式为 "N）"
  const indexElement = document.createElement('span');
  indexElement.className = 'note-index';
  indexElement.textContent = `${currentCount}）`;
  
  // 创建标题（使用content作为标题，后续提交时作为title）
  const titleElement = document.createElement('span');
  titleElement.className = 'note-title';
  titleElement.textContent = element.content;
  titleElement.title = element.content; // 完整标题显示在tooltip中
  
  // 创建URL（使用href作为URL，后续提交时使用）
  const urlElement = document.createElement('span');
  urlElement.className = 'note-url';
  urlElement.textContent = element.href;
  urlElement.title = element.href; // 完整URL显示在tooltip中
  
  // 添加点击复制URL功能
  urlElement.addEventListener('click', () => {
    copyToClipboard(element.href, urlElement);
  });
  
  // 添加点击复制标题功能（可选）
  titleElement.addEventListener('click', () => {
    copyToClipboard(element.content, titleElement);
  });
  
  // 将序列号和标题添加到标题行
  titleRow.appendChild(indexElement);
  titleRow.appendChild(titleElement);
  
  // 添加到笔记项
  noteItem.appendChild(titleRow);
  noteItem.appendChild(urlElement);
  
  // 添加到列表
  notesList.appendChild(noteItem);
  
  // 滚动到底部
  notesList.scrollTop = notesList.scrollHeight;
}

// 复制到剪贴板
function copyToClipboard(text, element) {
  navigator.clipboard.writeText(text)
    .then(() => {
      // 添加复制成功样式
      element.classList.add('copied');
      
      // 3秒后移除复制成功样式
      setTimeout(() => {
        element.classList.remove('copied');
      }, 3000);
    })
    .catch(err => {
      console.error('复制失败:', err);
    });
}

// 清空笔记列表
function clearNotesList() {
  const notesList = document.getElementById('notes-list');
  notesList.innerHTML = '<div class="empty-notes">暂无数据</div>';
  foundNotes.clear();
  // 更新笔记总数
  updateNotesCount();
}

// 更新笔记总数显示
function updateNotesCount() {
  const countElement = document.getElementById('notes-count');
  countElement.textContent = `(${foundNotes.size})`;
}

// 提交笔记
async function submitNotes() {
  // 检查是否有匹配的账号
  if (!matchedAccount) {
    alert('请先匹配账号');
    return;
  }
  
  // 检查是否有笔记数据
  if (foundNotes.size === 0) {
    alert('暂无笔记数据可提交');
    return;
  }
  
  // 构建mediaInfosStr数据
  const mediaInfos = Array.from(foundNotes).map(uniqueKey => {
    // 使用更可靠的方式拆分uniqueKey
    // 查找最后一个下划线的位置，因为content可能包含下划线
    const lastUnderscoreIndex = uniqueKey.lastIndexOf('_');
    if (lastUnderscoreIndex === -1) {
      return {
        itemId: '',
        title: '',
        url: ''
      };
    }
    
    const href = uniqueKey.substring(0, lastUnderscoreIndex);
    const content = uniqueKey.substring(lastUnderscoreIndex + 1);
    
    // 从URL中提取itemId
    let itemId = '';
    
    // 处理小红书URL
    const exploreIndex = href.indexOf('explore/');
    if (exploreIndex !== -1) {
      const itemIdStart = exploreIndex + 8;
      const itemIdEnd = href.indexOf('?', itemIdStart);
      itemId = itemIdEnd !== -1 ? href.substring(itemIdStart, itemIdEnd) : href.substring(itemIdStart);
    }
    // 处理抖音URL，从/video/或/note/后提取ID
    else if (href.includes('douyin.com/video/') || href.includes('douyin.com/note/')) {
      let idIndex = -1;
      if (href.includes('douyin.com/video/')) {
        idIndex = href.indexOf('video/');
      } else {
        idIndex = href.indexOf('note/');
      }
      
      if (idIndex !== -1) {
        const itemIdStart = idIndex + 6;
        const itemIdEnd = href.indexOf('?', itemIdStart);
        itemId = itemIdEnd !== -1 ? href.substring(itemIdStart, itemIdEnd) : href.substring(itemIdStart);
      }
    }
    
    return {
      itemId: itemId,
      title: content,
      url: href
    };
  });
  
  // 构建表单数据
  const formData = new FormData();
  formData.append('accountId', matchedAccount.accountId);
  formData.append('mediaInfosStr', JSON.stringify(mediaInfos));
  
  // 获取提交按钮并显示提交中状态
  const submitBtn = document.getElementById('submit-btn');
  const originalText = submitBtn.textContent;
  submitBtn.textContent = '提交中...';
  submitBtn.disabled = true;
  
  try {
    // 发送POST请求
    const response = await fetch('http://admin.tuitu.info/api/admin/flow/updateFlowMedias', {
      method: 'POST',
      body: formData
    });
    
    const result = await response.json();
    
    // 根据返回结果显示提示
    if (result.code === 0) {
      const { updateCount, updateFailCount } = result.data;
      alert(`提交成功！\n成功数量: ${updateCount}\n失败数量: ${updateFailCount}`);
    } else {
      alert(`提交失败: ${result.msg}`);
    }
  } catch (error) {
    console.error('提交请求失败:', error);
    alert('提交请求失败，请检查网络连接或服务器状态');
  } finally {
    // 恢复提交按钮状态
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  }
}

// 从存储中加载数据
function loadDataFromStorage() {
  return new Promise((resolve, reject) => {
    if (!currentTabId) {
      resolve();
      return;
    }
    
    const storageKey = `tab_${currentTabId}`;
    chrome.storage.local.get(storageKey, (result) => {
      if (chrome.runtime.lastError) {
        console.error('读取存储数据失败:', chrome.runtime.lastError);
        resolve();
        return;
      }
      
      const tabData = result[storageKey];
      if (tabData) {
        console.log('从存储中恢复数据:', tabData);
        
        // 恢复匹配结果
        matchedAccount = tabData.matchedAccount;
        if (matchedAccount) {
          const resultDiv = document.getElementById('match-result');
          resultDiv.textContent = `平台: ${matchedAccount.platform === 'dy' ? '抖音' : '小红书'} 用户ID: ${matchedAccount.userId}\n账号ID: ${matchedAccount.accountId}`;
          resultDiv.className = 'match-result success';
        }
        
        // 恢复笔记列表
        if (tabData.notes && Array.isArray(tabData.notes)) {
          tabData.notes.forEach(note => {
            const uniqueKey = `${note.href}_${note.content}`;
            foundNotes.add(uniqueKey);
            addNoteToUI(note);
          });
          
          // 更新笔记总数
          updateNotesCount();
        }
      }
      resolve();
    });
  });
}

// 保存数据到存储
function saveDataToStorage() {
  if (!currentTabId) {
    return;
  }
  
  // 转换Set为数组
  const notesArray = Array.from(foundNotes).map(uniqueKey => {
    // 使用更可靠的方式拆分uniqueKey
    // 查找最后一个下划线的位置，因为content可能包含下划线
    const lastUnderscoreIndex = uniqueKey.lastIndexOf('_');
    if (lastUnderscoreIndex === -1) {
      return {
        href: '',
        content: ''
      };
    }
    
    const href = uniqueKey.substring(0, lastUnderscoreIndex);
    const content = uniqueKey.substring(lastUnderscoreIndex + 1);
    
    return {
      href: href,    // 保存href作为url使用
      content: content // 保存content作为title使用
    };
  });
  
  const tabData = {
    matchedAccount: matchedAccount,
    notes: notesArray,
    timestamp: Date.now()
  };
  
  const storageKey = `tab_${currentTabId}`;
  const storageData = {};
  storageData[storageKey] = tabData;
  
  chrome.storage.local.set(storageData, () => {
    if (chrome.runtime.lastError) {
      console.error('保存数据到存储失败:', chrome.runtime.lastError);
    } else {
      console.log('数据已保存到存储');
    }
  });
}

// 清空当前标签页的数据
function clearTabData() {
  matchedAccount = null;
  foundNotes.clear();
  clearNotesList();
  
  // 清除存储中的数据
  if (currentTabId) {
    const storageKey = `tab_${currentTabId}`;
    chrome.storage.local.remove(storageKey, () => {
      if (chrome.runtime.lastError) {
        console.error('清除存储数据失败:', chrome.runtime.lastError);
      } else {
        console.log('已清除存储中的数据');
      }
    });
  }
}

// 获取当前标签页
function getCurrentTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        resolve(tabs[0]);
      } else {
        reject(new Error('无法获取当前标签页'));
      }
    });
  });
}

// 请求后端接口获取账号列表
async function fetchAccounts() {
  const response = await fetch('http://admin.tuitu.info/api/admin/flow/getAllAccount');
  if (!response.ok) {
    throw new Error(`HTTP错误! 状态: ${response.status}`);
  }
  const data = await response.json();
  if (data.code !== 0) {
    throw new Error(`接口错误: ${data.msg}`);
  }
  return data.data;
}
