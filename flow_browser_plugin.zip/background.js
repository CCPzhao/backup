// 监听标签页关闭事件
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  console.log(`标签页 ${tabId} 已关闭，清理对应数据`);
  
  // 移除对应tabId的存储数据
  const storageKey = `tab_${tabId}`;
  chrome.storage.local.remove(storageKey, () => {
    if (chrome.runtime.lastError) {
      console.error(`清理标签页 ${tabId} 数据失败:`, chrome.runtime.lastError);
    } else {
      console.log(`成功清理标签页 ${tabId} 的数据`);
    }
  });
});

// 监听标签页更新事件，用于检测页面刷新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // 检查是否是我们关心的URL（抖音/小红书用户页）
  const isTargetUrl = tab.url && (
    tab.url.includes('douyin.com/user/') || 
    tab.url.includes('xiaohongshu.com/user/profile/')
  );
  
  if (isTargetUrl) {
    // 检测页面刷新：从complete状态变为loading状态
    if (changeInfo.status === 'loading' && tab.status === 'loading') {
      console.log(`标签页 ${tabId} 正在刷新，清理对应数据`);
      
      // 移除对应tabId的存储数据
      const storageKey = `tab_${tabId}`;
      chrome.storage.local.remove(storageKey, () => {
        if (chrome.runtime.lastError) {
          console.error(`清理标签页 ${tabId} 刷新数据失败:`, chrome.runtime.lastError);
        } else {
          console.log(`成功清理标签页 ${tabId} 刷新时的数据`);
        }
      });
    }
  }
});

// 监听插件安装事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('Flow Plugin installed:', details);
  
  // 初始化时清理所有过期数据（可选）
  cleanExpiredData();
});

// 清理过期数据（超过24小时）
function cleanExpiredData() {
  console.log('开始清理过期数据...');
  
  const now = Date.now();
  const oneDay = 24 * 60 * 60 * 1000;
  
  chrome.storage.local.get(null, (items) => {
    if (chrome.runtime.lastError) {
      console.error('获取存储数据失败:', chrome.runtime.lastError);
      return;
    }
    
    const expiredKeys = [];
    
    // 遍历所有数据，找出过期的
    for (const [key, value] of Object.entries(items)) {
      // 只处理以"tab_"开头的数据
      if (key.startsWith('tab_') && value.timestamp) {
        // 检查是否超过24小时
        if (now - value.timestamp > oneDay) {
          expiredKeys.push(key);
        }
      }
    }
    
    if (expiredKeys.length > 0) {
      console.log(`找到 ${expiredKeys.length} 个过期数据，准备清理`);
      
      chrome.storage.local.remove(expiredKeys, () => {
        if (chrome.runtime.lastError) {
          console.error('清理过期数据失败:', chrome.runtime.lastError);
        } else {
          console.log(`成功清理 ${expiredKeys.length} 个过期数据`);
        }
      });
    } else {
      console.log('没有过期数据需要清理');
    }
  });
}
