// 全局变量
let isFindingElements = false;
let foundElementsSet = new Set(); // 用于去重
let mutationObserver = null;

// 监听来自popup.js的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Content script received message:', message);
  
  switch (message.type) {
    case 'GET_PAGE_DATA':
      // 获取页面数据
      const { platform, accountId } = extractPlatformAndAccountId(window.location.href);
      const pageData = {
        title: document.title,
        url: window.location.href,
        platform: platform,
        accountId: accountId
      };
      sendResponse(pageData);
      break;
      
    case 'START_FIND_ELEMENTS':
      // 开始查找页面元素
      if (!isFindingElements) {
        startFindElements();
      }
      sendResponse({ success: true });
      break;
      
    case 'STOP_FIND_ELEMENTS':
      // 停止查找页面元素
      stopFindElements();
      sendResponse({ success: true });
      break;
      
    default:
      sendResponse({ error: 'Unknown message type' });
  }
  
  return true; // 保持消息通道开放，以便异步发送响应
});

// 创建防抖版本的查找函数
const debouncedFindElements = debounce(findAndSendElements, 300);

// 开始查找页面元素
function startFindElements() {
  console.log('开始查找页面元素...');
  isFindingElements = true;
  
  // 第一次查找
  findAndSendElements();
  
  // 添加鼠标滑动事件监听
  document.addEventListener('scroll', debouncedFindElements);
  
  // 添加MutationObserver监听DOM变化
  setupMutationObserver();
}

// 停止查找页面元素
function stopFindElements() {
  console.log('停止查找页面元素');
  isFindingElements = false;
  
  // 移除事件监听器
  document.removeEventListener('scroll', debouncedFindElements);
  
  // 停止MutationObserver
  if (mutationObserver) {
    mutationObserver.disconnect();
    mutationObserver = null;
  }
  
  // 清空已找到的元素集合
  foundElementsSet.clear();
}

// 设置MutationObserver
function setupMutationObserver() {
  // 配置观察选项
  const config = {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
  };
  
  // 创建观察者
  mutationObserver = new MutationObserver((mutations) => {
    // 当DOM发生变化时查找元素
    findAndSendElements();
  });
  
  // 开始观察
  mutationObserver.observe(document.body, config);
}

// 查找并发送元素
function findAndSendElements() {
  if (!isFindingElements) return;
  
  try {
    // 获取当前页面的平台信息
    const { platform } = extractPlatformAndAccountId(window.location.href);
    const foundElements = [];
    
    if (platform === 'xhs') {
      // 小红书平台：查找class为'note-item'的section标签
      const noteSections = document.querySelectorAll('section.note-item');
      
      if (noteSections.length > 0) {
        noteSections.forEach(section => {
          try {
            // 尝试多种可能的标题选择器
            let titleElement = section.querySelector('.title span');
            if (!titleElement) {
              titleElement = section.querySelector('.title');
            }
            
            const content = titleElement ? titleElement.textContent.trim() : '';
            
            // 直接选择带有"cover mask ld" class的<a>标签
            const coverLink = section.querySelector('a.cover.mask.ld');
            if (!coverLink) return;
            
            let href = coverLink.getAttribute('href');
            if (!href) return;
              
            // 处理href，截取最后一个/后的值，拼接成新的URL
            // 保留完整的参数部分
            const lastSlashIndex = href.lastIndexOf('/');
            if (lastSlashIndex !== -1) {
              const pathAfterLastSlash = href.substring(lastSlashIndex + 1);
              // 拼接成完整的小红书explore URL，保留所有参数
              href = `https://www.xiaohongshu.com/explore/${pathAfterLastSlash}`;
            }
            
            // 生成唯一键，用于去重
            const uniqueKey = `${href}_${content}`;
            
            // 如果是新元素，添加到列表
            if (!foundElementsSet.has(uniqueKey)) {
              foundElementsSet.add(uniqueKey);
              foundElements.push({ href, content });
            }
          } catch (sectionError) {
            // 静默处理单个元素错误，不影响整体功能
          }
        });
      }
    } else {
      // 其他平台（如抖音）：使用原有的查找逻辑
      // 查找class为"uz1VJwFY TyuBARdT IdxE71f8"的<a>元素
      const targetLinks = document.querySelectorAll('a.uz1VJwFY.TyuBARdT.IdxE71f8');
      
      if (targetLinks.length > 0) {
        targetLinks.forEach(link => {
          // 获取href属性，并处理不同格式的URL
          let href = link.getAttribute('href');
          if (href) {
            if (href.startsWith('//')) {
              // 处理以//开头的URL，添加https:
              href = `https:${href}`;
            } else if (!href.startsWith('http')) {
              // 处理相对路径，拼接完整的抖音域名
              href = `https://www.douyin.com${href}`;
            }
          }
          
          // 查找该<a>元素下class为"eJFBAbdI H4IE9Xgd"的<p>元素
          const pElement = link.querySelector('p.eJFBAbdI.H4IE9Xgd');
          const content = pElement ? pElement.textContent.trim() : '';
          
          // 生成唯一键，用于去重
          const uniqueKey = `${href}_${content}`;
          
          // 如果是新元素，添加到列表
          if (!foundElementsSet.has(uniqueKey)) {
            foundElementsSet.add(uniqueKey);
            foundElements.push({ href, content });
          }
        });
      }
    }
    
    if (foundElements.length > 0) {
      // 发送给popup.js
      chrome.runtime.sendMessage({ 
        type: 'FOUND_ELEMENTS', 
        elements: foundElements 
      });
    }
  } catch (error) {
    // 静默处理错误，不影响整体功能
  }
}

// 防抖函数
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// 从URL中提取平台和accountId
function extractPlatformAndAccountId(url) {
  let platform = '';
  let accountId = '';
  
  if (url.includes('douyin.com/user/')) {
    platform = 'dy';
    // 正则提取抖音URL中的accountId
    const dyMatch = url.match(/douyin\.com\/user\/([^?]+)/);
    if (dyMatch && dyMatch[1]) {
      accountId = dyMatch[1];
    }
  } else if (url.includes('xiaohongshu.com/user/profile/')) {
    platform = 'xhs';
    // 正则提取小红书URL中的accountId
    const xhsMatch = url.match(/xiaohongshu\.com\/user\/profile\/([^?]+)/);
    if (xhsMatch && xhsMatch[1]) {
      accountId = xhsMatch[1];
    }
  }
  
  return { platform, accountId };
}

// 页面加载完成后执行
window.addEventListener('load', () => {
  console.log('Flow Plugin content script loaded');
});
