
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" -x 'META-INF/*' -d /mnt/sdcard/MIUI/xh


