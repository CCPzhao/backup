﻿echo "#!/system/bin/sh
if [ ${0%/*}/hidemomo ];then
su -c chmod 000 /mnt/vendor/persist/data
fi">$MODPATH/service.sh