#!/system/bin/sh
resetprop ro.boot.flash.locked 1
resetprop ro.boot.vbmeta.device_state locked
resetprop ro.secureboot.lockstate locked